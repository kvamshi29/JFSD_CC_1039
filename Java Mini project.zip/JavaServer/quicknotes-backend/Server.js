const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors()); // Enable CORS to allow frontend requests

mongoose.connect("mongodb://localhost:27017/quicknotes")
  .then(() => console.log("Connected to Local MongoDB!"))
  .catch((err) => console.error("MongoDB connection error:", err));

const NoteSchema = new mongoose.Schema({
  title: { type: String, required: true },
  content: { type: String, required: true }
});

const Note = mongoose.model("Note", NoteSchema);

// Get all notes
app.get("/notes", async (req, res) => {
  try {
    const notes = await Note.find();
    res.json(notes);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch notes" });
  }
});

// Add a new note
app.post("/notes", async (req, res) => {
  try {
    const { title, content } = req.body;
    if (!title || !content) {
      return res.status(400).json({ error: "Title and content are required" });
    }
    const newNote = new Note({ title, content });
    await newNote.save();
    res.json(newNote);
  } catch (err) {
    res.status(500).json({ error: "Failed to create note" });
  }
});

// Delete a note by ID
app.delete("/notes/:id", async (req, res) => {
  try {
    await Note.findByIdAndDelete(req.params.id);
    res.json({ message: "Note deleted!" });
  } catch (err) {
    res.status(500).json({ error: "Failed to delete note" });
  }
});

const PORT = 5000;
app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));